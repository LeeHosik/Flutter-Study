package com.example.chart_barchart_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
