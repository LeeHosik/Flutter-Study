package com.example.chart_piechart_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
