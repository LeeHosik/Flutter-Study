package com.example.r_iris_scatter_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
