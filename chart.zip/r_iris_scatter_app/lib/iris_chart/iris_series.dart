class IrisSeries {
  late double petalWidth;
  late double petalLength;
  late String species;

  IrisSeries({
    required this.petalWidth,
    required this.petalLength,
    required this.species,
  });
}
