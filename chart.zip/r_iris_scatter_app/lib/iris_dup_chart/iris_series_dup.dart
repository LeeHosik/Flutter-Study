class IrisSeriesDup {
  late double petalWidth;
  late double petalLength;
  late String species;
  late int dupCount;

  IrisSeriesDup(
      {required this.petalWidth,
      required this.petalLength,
      required this.species,
      required this.dupCount});
}
