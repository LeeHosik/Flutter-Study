package com.example.chart_linechart_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
