package com.example.textfield_login_data_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
